from django.apps import AppConfig


class ToursConfig(AppConfig):
    name = 'tours'
